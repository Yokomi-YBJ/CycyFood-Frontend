// frontend/constants/theme.js

export const COLORS = {
  primary: '#FF5F3B',       // Refined Coral/Orange
  secondary: '#2E7D32',     // Deep Green
  accent: '#FFB74D',        // Soft Amber
  background: '#F8F9FA',    // Off-white
  surface: '#FFFFFF',       // White for cards
  error: '#E53935',         // Red
  success: '#43A047',       // Green
  warning: '#FFA000',       // Amber
  info: '#039BE5',          // Blue
  text: {
    primary: '#1A1A1A',     // Near Black
    secondary: '#4A4A4A',   // Dark Grey
    disabled: '#9E9E9E',    // Light Grey
    onPrimary: '#FFFFFF',   // White on Primary
    onSecondary: '#FFFFFF', // White on Secondary
  },
  border: '#EEEEEE',
  overlay: 'rgba(0, 0, 0, 0.5)',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 40,
};

export const RADIUS = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const TYPOGRAPHY = {
  h1: { fontSize: 32, fontWeight: '900' },
  h2: { fontSize: 24, fontWeight: '800' },
  h3: { fontSize: 20, fontWeight: '700' },
  h4: { fontSize: 18, fontWeight: '700' },
  body: { fontSize: 16, fontWeight: '400' },
  caption: { fontSize: 14, fontWeight: '500' },
  small: { fontSize: 12, fontWeight: '400' },
};

export const SHADOWS = {
  light: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  heavy: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 10,
  },
};
