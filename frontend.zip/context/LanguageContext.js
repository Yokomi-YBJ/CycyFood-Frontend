// context/LanguageContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import { NativeModules, Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { i18n } from '../constants/i18n';

const LanguageContext = createContext();

const SECURE_STORE_KEY = 'latchop_locale';

// Détection de la langue du système de manière robuste et cross-platform
const getDeviceLanguage = () => {
  let locale = 'fr'; // Valeur par défaut de LaTchop

  try {
    if (Platform.OS === 'ios') {
      const settings = NativeModules.SettingsManager?.settings;
      const appleLocale = settings?.AppleLocale || settings?.AppleLanguages?.[0];
      if (appleLocale) {
        locale = appleLocale;
      }
    } else {
      const androidLocale = NativeModules.I18nManager?.localeIdentifier;
      if (androidLocale) {
        locale = androidLocale;
      }
    }
  } catch (e) {
    console.warn('Erreur lors de la détection de la langue système, repli sur FR :', e);
  }

  // Si la langue détectée commence par 'en', on utilise l'anglais, sinon français par défaut
  return locale.toLowerCase().startsWith('en') ? 'en' : 'fr';
};

export const LanguageProvider = ({ children }) => {
  const [locale, setLocaleState] = useState('fr');
  const [isLanguageReady, setIsLanguageReady] = useState(false);

  useEffect(() => {
    const loadSavedLocale = async () => {
      try {
        const savedLocale = await SecureStore.getItemAsync(SECURE_STORE_KEY);
        if (savedLocale === 'fr' || savedLocale === 'en') {
          setLocaleState(savedLocale);
        } else {
          // Si aucun choix n'est sauvegardé, on détecte la langue du système
          const deviceLang = getDeviceLanguage();
          setLocaleState(deviceLang);
          await SecureStore.setItemAsync(SECURE_STORE_KEY, deviceLang);
        }
      } catch (e) {
        console.error('Erreur lors du chargement de la langue sauvegardée :', e);
        setLocaleState(getDeviceLanguage());
      } finally {
        setIsLanguageReady(true);
      }
    };

    loadSavedLocale();
  }, []);

  const changeLocale = async (newLocale) => {
    if (newLocale === 'fr' || newLocale === 'en') {
      try {
        setLocaleState(newLocale);
        await SecureStore.setItemAsync(SECURE_STORE_KEY, newLocale);
      } catch (e) {
        console.error('Erreur lors de la sauvegarde de la langue :', e);
      }
    }
  };

  // Helper de traduction robuste : si la clé n'existe pas, retourne la clé elle-même
  const t = (key) => {
    const translationSet = i18n[locale] || i18n['fr'];
    return translationSet[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ locale, changeLocale, t, isLanguageReady }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
