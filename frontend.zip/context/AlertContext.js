// context/AlertContext.js
import React, { createContext, useContext, useState, useCallback } from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { COLORS, SPACING, RADIUS, SHADOWS } from '../constants/theme';

const AlertContext = createContext();

export const AlertProvider = ({ children }) => {
  const [alertConfig, setAlertConfig] = useState({
    visible: false,
    title: '',
    message: '',
    type: 'info', // 'info', 'success', 'error', 'warning'
    confirmText: 'OK',
    onConfirm: null,
    cancelText: null,
    onCancel: null,
  });

  const [fadeAnim] = useState(new Animated.Value(0));

  const showAlert = useCallback((config) => {
    setAlertConfig({
      visible: true,
      title: config.title || 'Information',
      message: config.message || '',
      type: config.type || 'info',
      confirmText: config.confirmText || 'OK',
      onConfirm: config.onConfirm || null,
      cancelText: config.cancelText || null,
      onCancel: config.onCancel || null,
    });

    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  const hideAlert = useCallback(() => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 250,
      useNativeDriver: true,
    }).start(() => {
      setAlertConfig((prev) => ({ ...prev, visible: false }));
    });
  }, [fadeAnim]);

  const handleConfirm = () => {
    if (alertConfig.onConfirm) {
      alertConfig.onConfirm();
    }
    hideAlert();
  };

  const getIconColor = () => {
    switch (alertConfig.type) {
      case 'success': return COLORS.success;
      case 'error': return COLORS.error;
      case 'warning': return COLORS.warning;
      default: return COLORS.primary;
    }
  };

  return (
    <AlertContext.Provider value={{ showAlert }}>
      {children}
      <Modal
        transparent
        visible={alertConfig.visible}
        animationType="fade"
        onRequestClose={hideAlert}
      >
        <View style={styles.overlay}>
          <Animated.View style={[styles.alertCard, { opacity: fadeAnim }]}>
            <View style={[styles.iconCircle, { backgroundColor: getIconColor() + '15' }]}>
              {alertConfig.type === 'success' && <Text style={{ fontSize: 30 }}>✅</Text>}
              {alertConfig.type === 'error' && <Text style={{ fontSize: 30 }}>❌</Text>}
              {alertConfig.type === 'warning' && <Text style={{ fontSize: 30 }}>⚠️</Text>}
              {alertConfig.type === 'info' && <Text style={{ fontSize: 30 }}>ℹ️</Text>}
            </View>

            <Text style={styles.title}>{alertConfig.title}</Text>
            <Text style={styles.message}>{alertConfig.message}</Text>

            <View style={styles.buttonContainer}>
              {alertConfig.cancelText && (
                <TouchableOpacity 
                  style={[styles.button, styles.cancelButton]} 
                  onPress={alertConfig.onCancel || hideAlert}
                >
                  <Text style={styles.cancelButtonText}>{alertConfig.cancelText}</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity 
                style={[styles.button, { backgroundColor: getIconColor(), flex: 1 }]} 
                onPress={handleConfirm}
              >
                <Text style={styles.buttonText}>{alertConfig.confirmText}</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Modal>
    </AlertContext.Provider>
  );
};

export const useAlert = () => {
  const context = useContext(AlertContext);
  if (!context) {
    throw new Error('useAlert must be used within an AlertProvider');
  }
  return context;
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.lg,
  },
  alertCard: {
    width: '100%',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.xl,
    padding: SPACING.xl,
    alignItems: 'center',
    ...SHADOWS.heavy,
  },
  iconCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: COLORS.text.primary,
    marginBottom: SPACING.sm,
    textAlign: 'center',
  },
  message: {
    fontSize: 16,
    color: COLORS.text.secondary,
    textAlign: 'center',
    marginBottom: SPACING.xl,
    lineHeight: 24,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: SPACING.md,
    width: '100%',
  },
  button: {
    height: 52,
    borderRadius: RADIUS.md,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
  },
  cancelButton: {
    backgroundColor: '#EEEEEE',
    flex: 1,
  },
  cancelButtonText: {
    color: COLORS.text.secondary,
    fontSize: 16,
    fontWeight: '600',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
});
