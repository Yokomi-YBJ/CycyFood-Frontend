// app/admin/index.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  RefreshControl, ActivityIndicator, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { Skeleton } from '../../components/Skeleton';
import { ENDPOINTS } from '../../constants/api';
import { COLORS, SPACING, RADIUS, SHADOWS } from '../../constants/theme';

// Palette dédiée pour l'Admin, dérivée du thème pour cohérence
const STATUS_COLORS = {
  pending:    { color: COLORS.warning, bg: COLORS.warning + '15' },
  confirmed:  { color: COLORS.info, bg: COLORS.info + '15' },
  delivering: { color: COLORS.secondary, bg: COLORS.secondary + '15' },
  delivered:  { color: COLORS.success, bg: COLORS.success + '15' },
  cancelled:  { color: COLORS.error, bg: COLORS.error + '15' },
};

const STATUT_CONFIG = {
  en_attente:   { ...STATUS_COLORS.pending,    label: 'En attente',   icon: 'time-outline' },
  confirmee:    { ...STATUS_COLORS.confirmed,  label: 'Confirmée',    icon: 'checkmark-circle-outline' },
  en_livraison: { ...STATUS_COLORS.delivering, label: 'En livraison', icon: 'bicycle-outline' },
  livree:       { ...STATUS_COLORS.delivered,  label: 'Livrée',       icon: 'bag-check-outline' },
  annulee:      { ...STATUS_COLORS.cancelled,  label: 'Annulée',      icon: 'close-circle-outline' },
};

const DashboardSkeleton = () => (
  <View style={{ padding: SPACING.md }}>
    <Skeleton width="100%" height={100} style={{ marginBottom: SPACING.lg, borderRadius: RADIUS.lg }} />
    <View style={styles.statsGrid}>
      <View style={[styles.statCard, { alignItems: 'center' }]}>
         <Skeleton width={48} height={48} style={{ borderRadius: RADIUS.md, marginBottom: 8 }} />
         <Skeleton width="60%" height={20} style={{ marginBottom: 4 }} />
         <Skeleton width="40%" height={12} />
      </View>
      <View style={[styles.statCard, { alignItems: 'center' }]}>
         <Skeleton width={48} height={48} style={{ borderRadius: RADIUS.md, marginBottom: 8 }} />
         <Skeleton width="60%" height={20} style={{ marginBottom: 4 }} />
         <Skeleton width="40%" height={12} />
      </View>
    </View>
    <Skeleton width="50%" height={20} style={{ marginVertical: SPACING.md }} />
    <Skeleton width="100%" height={60} style={{ marginBottom: SPACING.sm, borderRadius: RADIUS.lg }} />
    <Skeleton width="100%" height={60} style={{ marginBottom: SPACING.sm, borderRadius: RADIUS.lg }} />
  </View>
);

export default function AdminDashboard() {
  const { user, token } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState(null);
  const [recentes, setRecentes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = async () => {
    try {
      const res = await fetch(ENDPOINTS.adminStats, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.status === 'success') {
        setStats(data.stats);
        setRecentes(data.commandes_recentes);
      }
    } catch (e) {
      console.error('Erreur stats:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchStats(); }, []);
  const onRefresh = useCallback(() => { setRefreshing(true); fetchStats(); }, []);

  const StatCard = ({ icon, label, value, color }) => (
    <View style={styles.statCard}>
      <View style={[styles.statIcon, { backgroundColor: color + '15' }]}>
        <Ionicons name={icon} size={24} color={color} />
      </View>
      <Text style={styles.statVal}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.text.primary} />
      
      {/* Header Premium */}
      <View style={styles.header}>
        <Text style={styles.headerSub}>Dashboard</Text>
        <Text style={styles.headerTitle}>Admin Panel</Text>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[COLORS.primary]} />}
      >
        {loading ? (
          <DashboardSkeleton />
        ) : stats ? (
          <>
            {/* Chiffre d'affaires mis en avant */}
            <View style={styles.caCard}>
              <Text style={styles.caLabel}>Chiffre d'affaires</Text>
              <Text style={styles.caVal}>{stats.chiffre_affaires.toLocaleString()} Fcfa</Text>
            </View>

            {/* Grille de stats optimisée */}
            <View style={styles.statsGrid}>
              <StatCard icon="time-outline"       label="En attente"    value={stats.en_attente}    color={COLORS.warning} />
              <StatCard icon="checkmark-circle-outline" label="Confirmées" value={stats.confirmees} color={COLORS.info} />
              <StatCard icon="people-outline"     label="Clients"       value={stats.total_clients} color={COLORS.secondary} />
              <StatCard icon="restaurant-outline" label="Produits" value={`${stats.produits_dispo}`} color={COLORS.success} />
            </View>

            {/* Commandes récentes - Style "List View" propre */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Commandes récentes</Text>
              {recentes.map(cmd => {
                const cfg = STATUT_CONFIG[cmd.statut] || STATUT_CONFIG.en_attente;
                return (
                  <View key={cmd.id_commande} style={styles.cmdCard}>
                    <View style={styles.cmdInfo}>
                      <Text style={styles.cmdNom}>{cmd.nom_user} {cmd.prenom_user}</Text>
                      <Text style={styles.cmdDate}>{cmd.heure_commande?.slice(0,5)}</Text>
                    </View>
                    <View style={[styles.statutPill, { backgroundColor: cfg.bg }]}>
                      <Text style={[styles.statutText, { color: cfg.color }]}>{cfg.label}</Text>
                    </View>
                    <Text style={styles.cmdPrix}>{cmd.prix_commande} Fcfa</Text>
                  </View>
                );
              })}
            </View>
          </>
        ) : null}
        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  scroll: { paddingBottom: SPACING.xl },
  header: { padding: SPACING.lg, backgroundColor: COLORS.text.primary },
  headerSub: { fontSize: 12, color: COLORS.text.disabled, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1 },
  headerTitle: { fontSize: 28, fontWeight: '900', color: '#fff', marginTop: SPACING.sm },

  caCard: { margin: SPACING.md, backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.xl, ...SHADOWS.medium },
  caLabel: { fontSize: 14, color: COLORS.text.secondary, marginBottom: 4 },
  caVal: { fontSize: 32, fontWeight: '900', color: COLORS.text.primary },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: SPACING.sm, gap: SPACING.sm, marginBottom: SPACING.md },
  statCard: { width: '47%', backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, alignItems: 'center', ...SHADOWS.light, margin: SPACING.xs },
  statIcon: { width: 48, height: 48, borderRadius: RADIUS.md, alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.sm },
  statVal: { fontSize: 20, fontWeight: '900', color: COLORS.text.primary },
  statLabel: { fontSize: 12, color: COLORS.text.secondary, marginTop: 4 },

  section: { paddingHorizontal: SPACING.md, marginTop: SPACING.md },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text.primary, marginBottom: SPACING.md },
  
  cmdCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, marginBottom: SPACING.sm, gap: SPACING.md, ...SHADOWS.light },
  cmdInfo: { flex: 1 },
  cmdNom: { fontSize: 15, fontWeight: '700', color: COLORS.text.primary },
  cmdDate: { fontSize: 12, color: COLORS.text.secondary, marginTop: 2 },
  statutPill: { borderRadius: RADIUS.full, paddingHorizontal: 10, paddingVertical: 4 },
  statutText: { fontSize: 11, fontWeight: '700' },
  cmdPrix: { fontSize: 14, fontWeight: '800', color: COLORS.primary, width: 80, textAlign: 'right' },
});
