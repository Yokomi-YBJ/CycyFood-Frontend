// app/_layout.js
import { useState, useEffect, useRef } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { AuthProvider, useAuth } from '../context/AuthContext';
import { CartProvider } from '../context/CartContext';
import { AlertProvider } from '../context/AlertContext';
import { ErrorBoundary } from '../components/ErrorBoundary';
import {
  View, Text, StyleSheet, Animated, Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { COLORS, SPACING, RADIUS, TYPOGRAPHY, SHADOWS } from '../constants/theme';

// ── Écran de chargement animé ─────────────────────────────
function SplashLoading() {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const textFadeAnim = useRef(new Animated.Value(0)).current;
  const logoShadowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Animation principale
    Animated.sequence([
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
        Animated.spring(scaleAnim, { toValue: 1, tension: 20, friction: 7, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(textFadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        Animated.timing(logoShadowAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ]),
    ]).start();

    return () => {
      fadeAnim.stop();
      scaleAnim.stop();
      textFadeAnim.stop();
      logoShadowAnim.stop();
    };
  }, []);

  return (
    <View style={s.splash}>
      <StatusBar style="light" />
      
      <Animated.View style={[
        s.logoContainer, 
        { 
          opacity: fadeAnim, 
          transform: [{ scale: scaleAnim }],
          shadowOpacity: logoShadowAnim.interpolate({
            inputRange: [0, 1],
            outputRange: [0, 0.2]
          })
        }
      ]}>
        <Image source={require('../assets/logo.png')} style={s.logo} resizeMode="contain" />
      </Animated.View>

      <Animated.View style={[s.brandWrap, { opacity: textFadeAnim }]}>
        <Text style={s.brand}>LaTchop</Text>
        <View style={s.divider} />
        <Text style={s.tagline}>Local · Rapide · Délicieux</Text>
      </Animated.View>

      {/* Loading Indicator */}
      <View style={s.footer}>
        <Animated.View style={[s.loaderBar, { opacity: textFadeAnim }]}>
           <View style={s.loaderProgress} />
        </Animated.View>
      </View>
    </View>
  );
}

// ── Guard principal ───────────────────────────────────────
function RootGuard() {
  const { user, loading } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (loading) return;

    const inAuth = segments[0] === 'auth';
    const inAdmin = segments[0] === 'admin';

    if (!user && !inAuth) {
      router.replace('/auth/login');
    } else if (user?.role === 'admin' && !inAdmin) {
      router.replace('/admin');
    } else if (user && user.role !== 'admin' && (inAuth || inAdmin)) {
      router.replace('/(tabs)');
    }

    const timer = setTimeout(() => setIsReady(true), 100);
    return () => clearTimeout(timer);
  }, [user, loading, segments]);

  if (loading || !isReady) {
    return <SplashLoading />;
  }

  return (
    <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
      <Stack.Screen name="auth" />
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="admin" />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <ErrorBoundary>
        <AuthProvider>
          <CartProvider>
            <AlertProvider>
              <RootGuard />
            </AlertProvider>
          </CartProvider>
        </AuthProvider>
    </ErrorBoundary>
  );
}

const s = StyleSheet.create({
  splash: { 
    flex: 1, 
    backgroundColor: COLORS.primary, 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  logoContainer: { 
    width: 140, 
    height: 140, 
    borderRadius: RADIUS.xl, 
    backgroundColor: '#fff', 
    padding: 12,
    ...SHADOWS.heavy,
    marginBottom: SPACING.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: { 
    width: '100%', 
    height: '100%', 
  },
  brandWrap: { 
    alignItems: 'center', 
    marginTop: SPACING.md 
  },
  brand: { 
    fontSize: 42, 
    fontWeight: '900', 
    color: '#fff', 
    letterSpacing: 2 
  },
  divider: {
    width: 40,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.4)',
    borderRadius: 2,
    marginVertical: SPACING.sm,
  },
  tagline: { 
    fontSize: 14, 
    color: 'rgba(255,255,255,0.8)', 
    fontWeight: '500',
    letterSpacing: 1,
    textTransform: 'uppercase'
  },
  footer: {
    position: 'absolute',
    bottom: 60,
    width: '100%',
    alignItems: 'center'
  },
  loaderBar: {
    width: 100,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: RADIUS.full,
    overflow: 'hidden',
  },
  loaderProgress: {
    width: '50%',
    height: '100%',
    backgroundColor: '#fff',
    borderRadius: RADIUS.full,
  }
});