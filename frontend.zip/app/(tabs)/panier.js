// app/(tabs)/panier.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Image, ActivityIndicator, StatusBar,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useAlert } from '../../context/AlertContext';
import { ENDPOINTS } from '../../constants/api';
import { COLORS, SPACING, RADIUS, TYPOGRAPHY, SHADOWS } from '../../constants/theme';

export default function PanierScreen() {
  const insets = useSafeAreaInsets();
  const { cart, removeFromCart, incrementQuantite, decrementQuantite, viderPanier, totalPrix, totalArticles } = useCart();
  const { token } = useAuth();
  const { showAlert } = useAlert();
  const [loading, setLoading] = useState(false);
  const [livraison, setLivraison] = useState(false);

  const FRAIS_LIVRAISON = 1000;
  const totalFinal = livraison ? totalPrix + FRAIS_LIVRAISON : totalPrix;

  const passerCommande = async () => {
    if (cart.length === 0) {
      showAlert({ title: 'Panier vide', message: 'Ajoutez des plats savoureux depuis l\'accueil pour commencer votre festin !', type: 'warning' });
      return;
    }

    showAlert({
      title: 'Confirmer la commande',
      message: `Total : ${totalFinal} Fcfa${livraison ? '\nLivraison incluse (+' + FRAIS_LIVRAISON + ' Fcfa)' : '\nRetrait sur place'}`,
      type: 'info',
      confirmText: 'Confirmer',
      onConfirm: async () => {
        setLoading(true);
        try {
          const res = await fetch(ENDPOINTS.commandes, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              produits: cart.map(item => ({ id: item.id_produit, quantite: item.quantite })),
              prixTotal: totalFinal,
              avec_livraison: livraison,
            }),
          });
          const data = await res.json();
          if (data.status === 'success') {
            viderPanier();
            showAlert({
              title: '✅ Commande envoyée !',
              message: `Votre commande a bien été enregistrée.${livraison ? '\n🛵 Livraison incluse.' : '\nVeuillez vous rendre sur les lieux du retrait.'}`,
              type: 'success'
            });
          } else {
            showAlert({ title: 'Erreur', message: data.message, type: 'error' });
          }
        } catch (e) {
          showAlert({ title: 'Problème de connexion', message: 'Impossible d\'envoyer votre commande.', type: 'error' });
        } finally {
          setLoading(false);
        }
      },
    });
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemCard} accessible={true}>
      <Image
        source={{ uri: item.img_url }}
        style={styles.itemImg}
        defaultSource={require('../../assets/placeholder.png')}
        accessibilityLabel={`Image de ${item.nom_produit}`}
      />
      <View style={styles.itemInfo}>
        <Text style={styles.itemNom} numberOfLines={1}>{item.nom_produit}</Text>
        <Text style={styles.itemPriceUnit}>{item.Prix} Fcfa / unité</Text>
        
        <View style={styles.qtyRow}>
          <View style={styles.qtyContainer}>
            <TouchableOpacity 
              style={styles.qtyBtn} 
              onPress={() => decrementQuantite(item.id_produit)}
              accessible={true}
              accessibilityLabel="Diminuer la quantité de 1"
              accessibilityRole="button"
            >
              <Ionicons name="remove" size={18} color={COLORS.primary} />
            </TouchableOpacity>
            <Text style={styles.qtyText} accessibilityLabel={`Quantité : ${item.quantite}`}>{item.quantite}</Text>
            <TouchableOpacity 
              style={styles.qtyBtn} 
              onPress={() => incrementQuantite(item.id_produit)}
              accessible={true}
              accessibilityLabel="Augmenter la quantité de 1"
              accessibilityRole="button"
            >
              <Ionicons name="add" size={18} color={COLORS.primary} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      
      <View style={styles.itemRight}>
        <Text style={styles.itemTotal}>{item.Prix * item.quantite} Fcfa</Text>
        <TouchableOpacity 
          style={styles.deleteBtn} 
          onPress={() => removeFromCart(item.id_produit)}
          accessible={true}
          accessibilityLabel={`Supprimer ${item.nom_produit} du panier`}
          accessibilityRole="button"
        >
          <Ionicons name="trash-outline" size={20} color={COLORS.error} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <View style={[styles.content, { paddingTop: insets.top }]}>
        
        {/* ===== HEADER ===== */}
        <View style={styles.header}>
          <Text style={styles.headerTitle} accessibilityRole="header">Mon Panier</Text>
          {cart.length > 0 && (
            <TouchableOpacity 
              onPress={viderPanier} 
              style={styles.clearBtn}
              accessible={true}
              accessibilityLabel="Vider entièrement le panier de tous ses articles"
              accessibilityRole="button"
            >
              <Ionicons name="trash-outline" size={18} color={COLORS.error} />
              <Text style={styles.clearText}>Vider</Text>
            </TouchableOpacity>
          )}
        </View>

        {cart.length === 0 ? (
          <View style={styles.emptyContainer} accessible={true}>
            <View style={styles.emptyIconCircle}>
               <Ionicons name="cart-outline" size={64} color={COLORS.text.disabled} />
            </View>
            <Text style={styles.emptyTitle}>Panier vide</Text>
            <Text style={styles.emptyText}>Ajoutez des plats savoureux depuis l'accueil pour commencer votre festin !</Text>
          </View>
        ) : (
          <>
            <FlatList
              data={cart}
              keyExtractor={item => item.id_produit.toString()}
              renderItem={renderItem}
              contentContainerStyle={styles.list}
              showsVerticalScrollIndicator={false}
            />

            {/* ===== RECAP SECTION ===== */}
            <View style={styles.recapContainer}>
              <View style={styles.recapCard}>
                <View style={styles.recapRow}>
                  <Text style={styles.recapLabel}>Sous-total ({totalArticles} article{totalArticles > 1 ? 's' : ''})</Text>
                  <Text style={styles.recapVal}>{totalPrix} Fcfa</Text>
                </View>

                {/* Option livraison */}
                <TouchableOpacity 
                  activeOpacity={0.7}
                  style={[styles.deliveryToggle, livraison && styles.deliveryToggleActive]} 
                  onPress={() => setLivraison(!livraison)}
                  accessible={true}
                  accessibilityLabel="Activer ou désactiver l'option livraison à domicile"
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: livraison }}
                >
                  <View style={styles.deliveryLeft}>
                    <View style={[styles.checkbox, livraison && styles.checkboxActive]}>
                      {livraison && <Ionicons name="checkmark" size={14} color="#fff" />}
                    </View>
                    <View>
                      <Text style={styles.deliveryText}>Inclure la livraison</Text>
                      <Text style={styles.deliverySub}>+{FRAIS_LIVRAISON} Fcfa · À domicile</Text>
                    </View>
                  </View>
                  <Ionicons name="bicycle-outline" size={24} color={livraison ? '#fff' : COLORS.text.secondary} />
                </TouchableOpacity>

                <View style={styles.divider} />

                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total à payer</Text>
                  <Text style={styles.totalVal}>{totalFinal} Fcfa</Text>
                </View>

                <TouchableOpacity 
                  style={styles.orderBtn} 
                  onPress={passerCommande} 
                  disabled={loading}
                  accessible={true}
                  accessibilityLabel="Valider ma commande définitivement"
                  accessibilityRole="button"
                >
                  {loading
                    ? <ActivityIndicator color="#fff" />
                    : <>
                        <Ionicons name="checkmark-circle-outline" size={22} color="#fff" />
                        <Text style={styles.orderBtnText}>Commander maintenant</Text>
                      </>
                  }
                </TouchableOpacity>
              </View>
            </View>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { flex: 1 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.md, paddingTop: SPACING.md, paddingBottom: SPACING.md,
  },
  headerTitle: { fontSize: 28, fontWeight: '800', color: COLORS.text.primary },
  clearBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, padding: 4 },
  clearText: { color: COLORS.error, fontSize: 14, fontWeight: '600' },

  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: SPACING.xl },
  emptyIconCircle: {
    width: 120, height: 120, borderRadius: 60, backgroundColor: COLORS.surface,
    alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.lg,
    ...SHADOWS.light
  },
  emptyTitle: { fontSize: 24, fontWeight: '800', color: COLORS.text.primary, marginBottom: SPACING.sm },
  emptyText: { fontSize: 16, color: COLORS.text.secondary, textAlign: 'center', lineHeight: 24, marginBottom: SPACING.lg },

  list: { paddingHorizontal: SPACING.md, paddingBottom: SPACING.lg },
  itemCard: {
    flexDirection: 'row', backgroundColor: COLORS.surface, borderRadius: RADIUS.lg,
    marginBottom: SPACING.md, padding: SPACING.md,
    ...SHADOWS.light, alignItems: 'center'
  },
  itemImg: { width: 80, height: 80, borderRadius: RADIUS.md },
  itemInfo: { flex: 1, marginLeft: SPACING.md, justifyContent: 'center' },
  itemNom: { fontSize: 16, fontWeight: '700', color: COLORS.text.primary, marginBottom: 2 },
  itemPriceUnit: { fontSize: 13, color: COLORS.text.secondary, marginBottom: SPACING.sm },
  qtyRow: { flexDirection: 'row', alignItems: 'center' },
  qtyContainer: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.background,
    borderRadius: RADIUS.sm, padding: 4, borderWidth: 1, borderColor: COLORS.border
  },
  qtyBtn: { width: 28, height: 28, alignItems: 'center', justifyContent: 'center' },
  qtyText: { marginHorizontal: SPACING.md, fontSize: 16, fontWeight: '700', color: COLORS.text.primary },
  itemRight: { alignItems: 'flex-end', justifyContent: 'space-between', height: 80 },
  itemTotal: { fontSize: 15, fontWeight: '800', color: COLORS.primary },
  deleteBtn: { padding: 4 },

  recapContainer: {
    backgroundColor: COLORS.surface,
    borderTopLeftRadius: RADIUS.xl,
    borderTopRightRadius: RADIUS.xl,
    padding: SPACING.lg,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -10 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 20,
  },
  recapCard: { width: '100%' },
  recapRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: SPACING.md },
  recapLabel: { fontSize: 15, color: COLORS.text.secondary },
  recapVal: { fontSize: 15, fontWeight: '700', color: COLORS.text.primary },

  deliveryToggle: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: SPACING.md, borderRadius: RADIUS.lg, backgroundColor: COLORS.background,
    marginBottom: SPACING.md, borderWidth: 1, borderColor: COLORS.border
  },
  deliveryToggleActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  deliveryLeft: { flexDirection: 'row', alignItems: 'center', gap: SPACING.md },
  checkbox: {
    width: 22, height: 22, borderRadius: 6, borderWidth: 2,
    borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center',
  },
  checkboxActive: { backgroundColor: '#fff', borderColor: '#fff' },
  deliveryText: { fontSize: 15, fontWeight: '700', color: COLORS.text.primary },
  deliverySub: { fontSize: 12, color: COLORS.text.secondary },

  divider: { height: 1, backgroundColor: COLORS.border, marginBottom: SPACING.lg },

  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.lg },
  totalLabel: { fontSize: 18, fontWeight: '700', color: COLORS.text.primary },
  totalVal: { fontSize: 24, fontWeight: '900', color: COLORS.primary },

  orderBtn: {
    backgroundColor: COLORS.primary, borderRadius: RADIUS.lg, height: 56,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    ...SHADOWS.medium
  },
  orderBtnText: { color: '#fff', fontSize: 18, fontWeight: '800' },
});
