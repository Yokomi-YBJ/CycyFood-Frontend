// app/(tabs)/index.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Image, ActivityIndicator, RefreshControl, Dimensions, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useAlert } from '../../context/AlertContext';
import { Skeleton } from '../../components/Skeleton';
import { ENDPOINTS } from '../../constants/api';
import { COLORS, SPACING, RADIUS, TYPOGRAPHY, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');

const ProductSkeleton = () => (
  <View style={styles.produitCard}>
    <Skeleton width="100%" height={130} style={{ borderBottomLeftRadius: 0, borderBottomRightRadius: 0 }} />
    <View style={styles.produitInfo}>
      <Skeleton width="80%" height={16} style={{ marginBottom: 6 }} />
      <Skeleton width="50%" height={12} style={{ marginBottom: 12 }} />
      <Skeleton width="100%" height={36} style={{ borderRadius: RADIUS.md }} />
    </View>
  </View>
);

export default function HomeScreen() {
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { showAlert } = useAlert();
  const [produits, setProduits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [addedIds, setAddedIds] = useState({});

  const fetchProduits = async () => {
    try {
      const res = await fetch(ENDPOINTS.produits);
      const data = await res.json();
      if (data.status === 'success') {
        setProduits(data.produits);
      }
    } catch (e) {
      showAlert({ title: 'Problème de connexion', message: 'Impossible de charger les produits. Vérifiez votre connexion internet.', type: 'error' });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
   
  useEffect(() => { fetchProduits(); }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchProduits();
  }, []);

  const handleAddToCart = (produit) => {
    addToCart(produit);
    setAddedIds(prev => ({ ...prev, [produit.id_produit]: true }));
    setTimeout(() => {
      setAddedIds(prev => ({ ...prev, [produit.id_produit]: false }));
    }, 1200);
  };

  const heure = new Date().getHours();
  const salutation = heure < 12 ? 'Bonjour' : heure < 18 ? 'Bon après-midi' : 'Bonsoir';

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[COLORS.primary]} />}
      >
      <View style={styles.content}>
        {/* ===== HEADER ===== */}
        <View style={styles.header}>
          <View>
            <Text style={styles.userSalutation}>{salutation} 👋 </Text>
            <Text style={styles.userName}>{user?.nom_user}</Text>
          </View>
          <TouchableOpacity style={styles.notificationBtn}>
            <Ionicons name="notifications-outline" size={24} color={COLORS.text.primary} />
            <View style={styles.notifBadge} />
          </TouchableOpacity>
        </View>

        {/* ===== HERO BANNER ===== */}
        <View style={styles.hero}>
          <View style={styles.heroLeft}>
            <Text style={styles.heroTitle}>Le goût du {'\n'}local, {'\n'}chez vous.</Text>
            <Text style={styles.heroSub}>Commandez vos plats préférés en un clic.</Text>
            <TouchableOpacity style={styles.heroBtn}>
              <Text style={styles.heroBtnText}>Découvrir</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.heroRight}>
            <Image source={require('../../assets/logo.png')} style={styles.heroLogo} resizeMode="contain" />
          </View>
        </View>

        {/* ===== AVANTAGES ===== */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.avantages} contentContainerStyle={{ paddingRight: SPACING.lg }}>
          {[
            { icon: 'restaurant-outline', label: 'Qualité', color: COLORS.primary },
            { icon: 'flash-outline', label: 'Rapide', color: COLORS.secondary },
            { icon: 'wallet-outline', label: 'Économique', color: COLORS.accent },
          ].map((item, i) => (
            <View key={i} style={styles.avantageCard}>
              <View style={[styles.avantageIcon, { backgroundColor: item.color + '15' }]}>
                <Ionicons name={item.icon} size={24} color={item.color} />
              </View>
              <Text style={styles.avantageLabel}>{item.label}</Text>
            </View>
          ))}
        </ScrollView>

        {/* ===== NOS SPÉCIALITÉS ===== */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Nos <Text style={styles.accent}>Spécialités</Text></Text>
            <TouchableOpacity><Text style={styles.seeAll}>Voir tout</Text></TouchableOpacity>
          </View>
        </View>

        {loading ? (
          <View style={styles.produitsGrid}>
            <ProductSkeleton />
            <ProductSkeleton />
            <ProductSkeleton />
            <ProductSkeleton />
          </View>
        ) : (
          <>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.specialites} contentContainerStyle={{ paddingRight: SPACING.lg }}>
              {produits.map(p => (
                <View key={p.id_produit} style={styles.specialiteCard}>
                  <Image
                    source={{ uri: p.img_url }}
                    style={styles.specialiteImg}
                    defaultSource={require('../../assets/placeholder.png')}
                  />
                  <View style={styles.specialiteContent}>
                    <Text style={styles.specialiteNom} numberOfLines={1}>{p.nom_produit}</Text>
                    <Text style={styles.specialiteDesc} numberOfLines={1}>{p.description}</Text>
                  </View>
                </View>
              ))}
            </ScrollView>

            {/* ===== PLATS POPULAIRES ===== */}
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Plats <Text style={styles.accent}>Populaires</Text></Text>
              </View>
            </View>

            <View style={styles.produitsGrid}>
              {produits.map(p => (
                <View key={p.id_produit} style={styles.produitCard}>
                  <Image
                    source={{ uri: p.img_url }}
                    style={styles.produitImg}
                    defaultSource={require('../../assets/placeholder.png')}
                  />
                  <View style={styles.produitPriceBadge}>
                    <Text style={styles.produitPrice}>{p.Prix} Fcfa</Text>
                  </View>
                  <View style={styles.produitInfo}>
                    <Text style={styles.produitNom} numberOfLines={1}>{p.nom_produit}</Text>
                    <View style={styles.stars}>
                      {[1, 2, 3, 4, 5].map(s => (
                        <Ionicons key={s} name="star" size={12} color="#FFD700" />
                      ))}
                    </View>
                    <TouchableOpacity
                      style={[styles.btnCommander, addedIds[p.id_produit] && styles.btnCommanderActive]}
                      onPress={() => handleAddToCart(p)}
                    >
                      <Ionicons
                        name={addedIds[p.id_produit] ? 'checkmark-circle' : 'bag-add-outline'}
                        size={18} color="#fff"
                      />
                      <Text style={styles.btnCommanderText}>
                        {addedIds[p.id_produit] ? 'Ajouté' : 'Commander'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          </>
        )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const CARD_W = (width - (SPACING.md * 3)) / 2;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { flex: 1 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.md, paddingTop: SPACING.md, paddingBottom: SPACING.sm,
  },
  userSalutation: { fontSize: 14, color: COLORS.text.secondary, fontWeight: '500' },
  userName: { fontSize: 22, fontWeight: '800', color: COLORS.text.primary },
  notificationBtn: { 
    width: 44, height: 44, borderRadius: RADIUS.full, backgroundColor: COLORS.surface,
    alignItems: 'center', justifyContent: 'center', ...SHADOWS.light 
  },
  notifBadge: {
    position: 'absolute', top: 12, right: 12, width: 10, height: 10,
    borderRadius: 5, backgroundColor: COLORS.error, borderWidth: 2, borderColor: COLORS.surface
  },

  hero: {
    marginHorizontal: SPACING.md, marginVertical: SPACING.md, borderRadius: RADIUS.xl,
    backgroundColor: COLORS.primary, padding: SPACING.lg, flexDirection: 'row',
    ...SHADOWS.medium, overflow: 'hidden'
  },
  heroLeft: { flex: 1, justifyContent: 'center' },
  heroTitle: { fontSize: 26, fontWeight: '900', color: '#fff', lineHeight: 32 },
  heroSub: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: SPACING.sm, marginBottom: SPACING.md },
  heroBtn: {
    backgroundColor: '#fff', paddingHorizontal: SPACING.lg, paddingVertical: SPACING.sm,
    borderRadius: RADIUS.full, alignSelf: 'flex-start'
  },
  heroBtnText: { color: COLORS.primary, fontWeight: '700', fontSize: 14 },
  heroRight: { justifyContent: 'center', alignItems: 'center' },
  heroLogo: { width: 100, height: 100, borderRadius: RADIUS.lg, opacity: 0.9 },

  avantages: { paddingLeft: SPACING.md, paddingVertical: SPACING.md },
  avantageCard: {
    alignItems: 'center', marginRight: SPACING.md,
    backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md,
    width: 100, ...SHADOWS.light,
  },
  avantageIcon: { width: 40, height: 40, borderRadius: RADIUS.full, alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.sm },
  avantageLabel: { fontSize: 12, fontWeight: '700', color: COLORS.text.primary, textAlign: 'center' },

  section: { paddingHorizontal: SPACING.md, paddingTop: SPACING.lg },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  sectionTitle: { fontSize: 20, fontWeight: '800', color: COLORS.text.primary },
  accent: { color: COLORS.primary },
  seeAll: { fontSize: 14, color: COLORS.primary, fontWeight: '600' },

  specialites: { paddingLeft: SPACING.md, paddingVertical: SPACING.sm },
  specialiteCard: {
    width: 160, marginRight: SPACING.md, borderRadius: RADIUS.lg, backgroundColor: COLORS.surface,
    overflow: 'hidden', ...SHADOWS.light,
  },
  specialiteImg: { width: '100%', height: 110 },
  specialiteContent: { padding: SPACING.md },
  specialiteNom: { fontSize: 14, fontWeight: '700', color: COLORS.text.primary },
  specialiteDesc: { fontSize: 11, color: COLORS.text.secondary, marginTop: 2 },

  produitsGrid: {
    flexDirection: 'row', flexWrap: 'wrap',
    paddingHorizontal: SPACING.md, gap: SPACING.md, marginBottom: SPACING.lg,
  },
  produitCard: {
    width: CARD_W, borderRadius: RADIUS.xl, backgroundColor: COLORS.surface,
    overflow: 'hidden', ...SHADOWS.medium,
  },
  produitImg: { width: '100%', height: 130 },
  produitPriceBadge: {
    position: 'absolute', top: 10, right: 10,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: RADIUS.sm,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  produitPrice: { color: '#fff', fontSize: 12, fontWeight: '700' },
  produitInfo: { padding: SPACING.md },
  produitNom: { fontSize: 15, fontWeight: '700', color: COLORS.text.primary, marginBottom: 4 },
  stars: { flexDirection: 'row', gap: 1, marginBottom: 12 },
  btnCommander: {
    backgroundColor: COLORS.primary, borderRadius: RADIUS.md, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10,
  },
  btnCommanderActive: { backgroundColor: COLORS.success },
  btnCommanderText: { color: '#fff', fontSize: 13, fontWeight: '700' },
});
