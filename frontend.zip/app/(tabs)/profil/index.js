// app/(tabs)/profil/index.js
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../../context/AuthContext';
import { useCart } from '../../../context/CartContext';
import { useAlert } from '../../../context/AlertContext';
import { useTranslation } from '../../../context/LanguageContext';
import { COLORS, SPACING, RADIUS, TYPOGRAPHY, SHADOWS } from '../../../constants/theme';

export default function ProfilScreen() {
  const { user, deconnexion } = useAuth();
  const { totalArticles } = useCart();
  const { showAlert } = useAlert();
  const { t, locale, changeLocale } = useTranslation();
  const router = useRouter();

  const handleDeconnexion = () => {
    showAlert({
      title: t('logout'),
      message: 'Êtes-vous sûr de vouloir vous déconnecter ?',
      type: 'warning',
      confirmText: t('logout'),
      onConfirm: async () => {
        await deconnexion();
        router.replace('/auth/login');
      },
    });
  };

  const ouvrirWhatsApp = () => {
    const numero = '237691094048';
    Linking.openURL(`whatsapp://send?phone=+${numero}`)
      .catch(() => Linking.openURL(`https://wa.me/${numero}`));
  };

  const initiales = user
    ? `${(user.nom_user || '?')[0]}${(user.prenom_user || '?')[0]}`.toUpperCase()
    : '??';

  const MenuItem = ({ icon, label, value, color, onPress, chevron }) => (
    <TouchableOpacity
      style={styles.menuItem}
      onPress={onPress}
      activeOpacity={onPress ? 0.6 : 1}
      disabled={!onPress}
    >
      <View style={[styles.menuIcon, { backgroundColor: (color || COLORS.primary) + '15' }]}>
        <Ionicons name={icon} size={20} color={color || COLORS.primary} />
      </View>
      <View style={styles.menuContent}>
        <Text style={styles.menuLabel}>{label}</Text>
        {value ? <Text style={styles.menuValue} numberOfLines={1}>{value}</Text> : null}
      </View>
      {(onPress || chevron) && <Ionicons name="chevron-forward" size={16} color="#ccc" />}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.containt}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.primary} />
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{initiales}</Text>
          </View>
          <Text style={styles.userName}>{user?.nom_user} {user?.prenom_user}</Text>
          
          <TouchableOpacity
            style={styles.editHeaderBtn}
            onPress={() => router.push('profil/modifier')}
          >
            <Ionicons name="pencil-outline" size={14} color="#fff" />
            <Text style={styles.editHeaderBtnText}>Modifier</Text>
          </TouchableOpacity>
        </View>

        {/* Langue */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('language')}</Text>
          <View style={styles.card}>
            <View style={styles.menuItem}>
              <View style={[styles.menuIcon, { backgroundColor: COLORS.primary + '15' }]}>
                <Ionicons name="language-outline" size={20} color={COLORS.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuLabel}>{t('french')}</Text>
              </View>
              <TouchableOpacity style={[styles.langBtn, locale === 'fr' && styles.langBtnActive]} onPress={() => changeLocale('fr')}>
                <Text style={[styles.langBtnText, locale === 'fr' && {color: '#fff'}]}>FR</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.langBtn, locale === 'en' && styles.langBtnActive]} onPress={() => changeLocale('en')}>
                <Text style={[styles.langBtnText, locale === 'en' && {color: '#fff'}]}>EN</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Mes informations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('info')}</Text>
          <View style={styles.card}>
            <MenuItem
              icon="call-outline"
              label={t('phone')}
              value={user?.telephone?.toString()}
            />
            <View style={styles.divider} />
            <MenuItem
              icon="location-outline"
              label={t('address')}
              value={user?.adresse_user}
            />
            <View style={styles.divider} />
            <MenuItem
              icon="create-outline"
              label={t('edit_info')}
              color={COLORS.primary}
              onPress={() => router.push('profil/modifier')}
              chevron
            />
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>🛒</Text>
            <Text style={styles.statVal}>{totalArticles}</Text>
            <Text style={styles.statLabel}>{t('cart')}</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>📦</Text>
            <Text style={styles.statVal}>—</Text>
            <Text style={styles.statLabel}>{t('order')}</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>🎁</Text>
            <Text style={styles.statVal}>0</Text>
            <Text style={styles.statLabel}>Fidélité</Text>
          </View>
        </View>

        {/* Support */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('support')}</Text>
          <View style={styles.card}>
            <MenuItem
              icon="logo-whatsapp"
              label={t('contact_us')}
              value="Service Client"
              color="#4CAF50"
              onPress={ouvrirWhatsApp}
            />
          </View>
        </View>

        {/* Légal */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('legal')}</Text>
          <View style={styles.card}>
            <MenuItem
              icon="document-text-outline"
              label={t('cgu')}
              color="#2196F3"
              onPress={() => router.push('profil/cgu')}
              chevron
            />
            <View style={styles.divider} />
            <MenuItem
              icon="shield-outline"
              label={t('privacy')}
              color="#9C27B0"
              onPress={() => router.push('profil/confidentialite')}
              chevron
            />
          </View>
        </View>

        {/* À propos */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('about')}</Text>
          <View style={styles.card}>
            <MenuItem
              icon="information-circle-outline"
              label={t('version')}
              value="1.0.0"
              color="#888"
            />
            <View style={styles.divider} />
            <MenuItem
              icon="code-slash-outline"
              label={t('developed_by')}
              value="Yokomi Beyea J. & Mbanga David"
              color="#888"
            />
          </View>
        </View>

        {/* Déconnexion */}
        <TouchableOpacity style={styles.btnDeconnexion} onPress={handleDeconnexion}>
          <Ionicons name="log-out-outline" size={20} color="#fff" />
          <Text style={styles.btnDeconnexionText}>{t('logout')}</Text>
        </TouchableOpacity>

        <View style={{ height: 32 }} />
      </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.primary },
  containt: { flex: 1, backgroundColor: COLORS.background },
  profileHeader: {
    alignItems: 'center',
    paddingTop: SPACING.xl,
    paddingBottom: SPACING.xl,
    backgroundColor: COLORS.primary,
  },
  avatar: {
    width: 86,
    height: 86,
    borderRadius: 43,
    backgroundColor: COLORS.surface + '40',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.sm,
    borderWidth: 3,
    borderColor: COLORS.surface + '66',
  },
  avatarText: { fontSize: 30, fontWeight: '900', color: COLORS.text.onPrimary },
  userName: { fontSize: 22, fontWeight: '800', color: COLORS.text.onPrimary, marginBottom: SPACING.xs },
  editHeaderBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    backgroundColor: COLORS.surface + '33',
    borderRadius: RADIUS.full,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderWidth: 1,
    borderColor: COLORS.surface + '59',
  },
  editHeaderBtnText: { color: COLORS.text.onPrimary, fontSize: 13, fontWeight: '600' },

  langBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: RADIUS.sm, backgroundColor: COLORS.background, marginLeft: 8 },
  langBtnActive: { backgroundColor: COLORS.primary },
  langBtnText: { fontSize: 12, fontWeight: '700', color: COLORS.text.secondary },

  section: { paddingHorizontal: SPACING.md, marginTop: SPACING.lg },
  sectionTitle: {
    ...TYPOGRAPHY.caption,
    color: COLORS.text.secondary,
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    marginBottom: SPACING.sm,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: SPACING.md, gap: SPACING.md },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: RADIUS.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuContent: { flex: 1 },
  menuLabel: { fontSize: 14, fontWeight: '600', color: COLORS.text.primary },
  menuValue: { fontSize: 12, color: COLORS.text.secondary, marginTop: SPACING.xs },
  divider: { height: 1, backgroundColor: COLORS.border, marginLeft: 66 },

  statsRow: { flexDirection: 'row', paddingHorizontal: SPACING.md, gap: SPACING.sm, marginTop: SPACING.lg },
  statCard: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    alignItems: 'center',
    ...SHADOWS.light,
  },
  statEmoji: { fontSize: 22, marginBottom: SPACING.xs },
  statVal: { fontSize: 18, fontWeight: '900', color: COLORS.text.primary },
  statLabel: { fontSize: 10, color: COLORS.text.secondary, marginTop: SPACING.xs },

  btnDeconnexion: {
    marginHorizontal: SPACING.md,
    marginTop: SPACING.lg,
    backgroundColor: COLORS.error,
    borderRadius: RADIUS.md,
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.sm,
    ...SHADOWS.medium,
  },
  btnDeconnexionText: { color: COLORS.text.onPrimary, fontSize: 16, fontWeight: '700' },
});
