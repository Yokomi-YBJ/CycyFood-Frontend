// app/auth/signup.js
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator,
  Alert, Image, StatusBar, Modal, Animated, Dimensions, Linking,
} from 'react-native';
import { useRouter, Link } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useAlert } from '../../context/AlertContext';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, RADIUS, TYPOGRAPHY, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');

// l'URL de ta politique de confidentialité en ligne
const URL_POLITIQUE = 'https://cycy-food-politique-de-confidential.vercel.app/';

const QUARTIERS = [
  { label: 'Baladji', value: 'Baladji', arr: '1' },
  { label: 'Bamyanga', value: 'Bamyanga', arr: '1' },
  { label: 'Bini-Dang', value: 'Bini-Dang', arr: '1' },
  { label: 'Burkina', value: 'Burkina', arr: '1' },
  { label: 'Dang', value: 'Dang', arr: '1' },
  { label: 'Gadamabanga', value: 'Gadamabanga', arr: '1' },
  { label: 'Joli-Soir', value: 'Joli-Soir', arr: '1' },
  { label: 'Mbideng', value: 'Mbideng', arr: '1' },
  { label: 'Ngaoundaba', value: 'Ngaoundaba', arr: '1' },
  { label: 'Sabongari', value: 'Sabongari', arr: '1' },
  { label: 'Bamoun', value: 'Bamoun', arr: '2' },
  { label: 'Centre Commercial', value: 'Centre Commercial', arr: '2' },
  { label: 'Château', value: 'Château', arr: '2' },
  { label: 'Hamakoussou', value: 'Hamakoussou', arr: '2' },
  { label: 'Hippodrome', value: 'Hippodrome', arr: '2' },
  { label: 'Marché Central', value: 'Marché Central', arr: '2' },
  { label: 'Mbidou', value: 'Mbidou', arr: '2' },
  { label: 'Plateau', value: 'Plateau', arr: '2' },
  { label: 'Rue de Garoua', value: 'Rue de Garoua', arr: '2' },
  { label: 'Socaret', value: 'Socaret', arr: '2' },
  { label: 'Beka', value: 'Beka', arr: '3' },
  { label: 'Béré', value: 'Béré', arr: '3' },
  { label: 'Bilanga', value: 'Bilanga', arr: '3' },
  { label: 'Djalingo', value: 'Djalingo', arr: '3' },
  { label: 'Gounfan', value: 'Gounfan', arr: '3' },
  { label: 'Maourou', value: 'Maourou', arr: '3' },
  { label: 'Mbitom', value: 'Mbitom', arr: '3' },
  { label: 'Nganha', value: 'Nganha', arr: '3' },
  { label: 'Wack', value: 'Wack', arr: '3' },
  { label: 'Wolordé', value: 'Wolordé', arr: '3' },
];

const ETAPES = [
  { titre: 'Qui êtes-vous ?', sous: 'Étape 1 sur 3', icon: 'person-outline' },
  { titre: 'Où habitez-vous ?', sous: 'Étape 2 sur 3', icon: 'location-outline' },
  { titre: 'Sécurisez votre compte', sous: 'Étape 3 sur 3', icon: 'lock-closed-outline' },
];

export default function SignupScreen() {
  const router = useRouter();
  const { inscription } = useAuth();
  const { showAlert } = useAlert();

  const [etape, setEtape] = useState(0);
  const [nom, setNom] = useState('');
  const [prenom, setPrenom] = useState('');
  const [adresse, setAdresse] = useState('');
  const [telephone, setTelephone] = useState('');
  const [password, setPassword] = useState('');
  const [copassword, setCopassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [showCoPass, setShowCoPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [recherche, setRecherche] = useState('');
  const [acceptePolitique, setAcceptePolitique] = useState(false);
  const [checkboxShake, setCheckboxShake] = useState(false);

  const slideAnim = useRef(new Animated.Value(0)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;

  const animer = (direction) => {
    Animated.sequence([
      Animated.timing(slideAnim, {
        toValue: direction === 'next' ? -40 : 40,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 250,
        useNativeDriver: true,
      }),
    ]).start();
  };

  // Animation secousse pour la checkbox si non cochée
  const animerShake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 6, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -6, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const quartiersFiltres = QUARTIERS.filter(q =>
    q.label.toLowerCase().includes(recherche.toLowerCase())
  );

  const validerEtape = () => {
    if (etape === 0) {
      if (!nom.trim()) {
        showAlert({ title: 'Champ requis', message: 'Veuillez entrer votre nom.', type: 'warning' });
        return;
      }
      if (!prenom.trim()) {
        showAlert({ title: 'Champ requis', message: 'Veuillez entrer votre prénom.', type: 'warning' });
        return;
      }
    }
    if (etape === 1) {
      if (!adresse) {
        showAlert({ title: 'Champ requis', message: 'Veuillez choisir votre quartier.', type: 'warning' });
        return;
      }
      if (!telephone || telephone.length !== 9) {
        showAlert({ title: 'Téléphone invalide', message: 'Le numéro doit contenir 9 chiffres.', type: 'error' });
        return;
      }
    }
    animer('next');
    setEtape(e => e + 1);
  };

  const retour = () => {
    animer('back');
    setEtape(e => e - 1);
  };

  const handleInscription = async () => {
    if (password.length < 6) {
      showAlert({ title: 'Mot de passe trop court', message: 'Minimum 6 caractères.', type: 'warning' });
      return;
    }
    if (password !== copassword) {
      showAlert({ title: 'Mots de passe différents', message: 'Les mots de passe ne correspondent pas.', type: 'error' });
      return;
    }

    // Vérification checkbox obligatoire
    if (!acceptePolitique) {
      animerShake();
      showAlert({ title: 'Politique requise', message: 'Veuillez accepter la politique de confidentialité.', type: 'warning' });
      return;
    }

    setLoading(true);
    try {
      const data = await inscription({ nom, prenom, adresse, telephone, password, copassword });
      if (data.status === 'success') {
        router.replace('/(tabs)');
      } else {
        showAlert({ title: 'Erreur', message: data.message, type: 'error' });
      }
    } catch (e) {
      showAlert({ title: 'Erreur réseau', message: 'Impossible de contacter le serveur.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const ouvrirPolitique = () => {
    Linking.openURL(URL_POLITIQUE).catch(() => {
      showAlert({ title: 'Erreur', message: 'Impossible d\'ouvrir la page.', type: 'error' });
    });
  };

  return (
    <>
      <StatusBar barStyle="light-content" />

      {/* Modal quartiers */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Choisir un quartier</Text>
              <TouchableOpacity onPress={() => { setModalVisible(false); setRecherche(''); }}>
                <Ionicons name="close" size={24} color={COLORS.text.primary} />
              </TouchableOpacity>
            </View>
            <View style={styles.searchWrapper}>
              <Ionicons name="search-outline" size={18} color={COLORS.text.disabled} />
              <TextInput
                style={styles.searchInput}
                placeholder="Rechercher..."
                placeholderTextColor={COLORS.text.disabled}
                value={recherche}
                onChangeText={setRecherche}
                autoCorrect={false}
              />
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {['1', '2', '3'].map(arr => {
                const liste = quartiersFiltres.filter(q => q.arr === arr);
                if (liste.length === 0) return null;
                return (
                  <View key={arr}>
                    <Text style={styles.arrLabel}>Ngaoundéré {arr}</Text>
                    {liste.map(item => (
                      <TouchableOpacity
                        key={item.value}
                        style={[styles.quartierItem, adresse === item.value && styles.quartierItemSelected]}
                        onPress={() => { setAdresse(item.value); setModalVisible(false); setRecherche(''); }}
                      >
                        <Ionicons
                          name={adresse === item.value ? 'radio-button-on' : 'radio-button-off'}
                          size={18} color={adresse === item.value ? COLORS.primary : COLORS.text.disabled}
                        />
                        <Text style={[styles.quartierText, adresse === item.value && styles.quartierTextSelected]}>
                          {item.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>

      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Logo */}
          <View style={styles.header}>
            <View style={styles.logoContainer}>
              <Image source={require('../../assets/logo.png')} style={styles.logoImg} />
            </View>
            <Text style={styles.brandName}>LaTchop</Text>
          </View>

          {/* Barre de progression */}
          <View style={styles.progressContainer}>
            {ETAPES.map((_, i) => (
              <View key={i} style={styles.progressStep}>
                <View style={[
                  styles.progressDot,
                  i <= etape && styles.progressDotActive,
                  i < etape && styles.progressDotDone,
                ]}>
                  {i < etape
                    ? <Ionicons name="checkmark" size={13} color="#fff" />
                    : <Text style={[styles.progressNum, i === etape && styles.progressNumActive]}>{i + 1}</Text>
                  }
                </View>
                {i < ETAPES.length - 1 && (
                  <View style={[styles.progressLine, i < etape && styles.progressLineDone]} />
                )}
              </View>
            ))}
          </View>

          {/* Card animée */}
          <Animated.View style={[styles.card, { transform: [{ translateX: slideAnim }] }]}>
            <View style={styles.etapeHeader}>
              <View style={styles.etapeIconWrap}>
                <Ionicons name={ETAPES[etape].icon} size={22} color={COLORS.primary} />
              </View>
              <View>
                <Text style={styles.etapeSous}>{ETAPES[etape].sous}</Text>
                <Text style={styles.etapeTitre}>{ETAPES[etape].titre}</Text>
              </View>
            </View>

            {/* STEP 1 */}
            {etape === 0 && (
              <View>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Nom</Text>
                  <View style={styles.inputWrapper}>
                    <Ionicons name="person-outline" size={18} color={COLORS.primary} />
                    <TextInput
                      style={styles.input}
                      placeholder="Votre nom de famille"
                      placeholderTextColor={COLORS.text.disabled}
                      value={nom}
                      onChangeText={setNom}
                      autoCorrect={false}
                      autoCapitalize="words"
                    />
                  </View>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Prénom</Text>
                  <View style={styles.inputWrapper}>
                    <Ionicons name="person-circle-outline" size={18} color={COLORS.primary} />
                    <TextInput
                      style={styles.input}
                      placeholder="Votre prénom"
                      placeholderTextColor={COLORS.text.disabled}
                      value={prenom}
                      onChangeText={setPrenom}
                      autoCorrect={false}
                      autoCapitalize="words"
                    />
                  </View>
                </View>
              </View>
            )}

            {/* STEP 2 */}
            {etape === 1 && (
              <View>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Quartier</Text>
                  <TouchableOpacity style={styles.inputWrapper} onPress={() => setModalVisible(true)} activeOpacity={0.7}>
                    <Ionicons name="location-outline" size={18} color={COLORS.primary} />
                    <Text style={[styles.selectText, !adresse && { color: COLORS.text.disabled }]}>
                      {adresse || 'Sélectionner votre quartier'}
                    </Text>
                    <Ionicons name="chevron-down" size={16} color={COLORS.text.disabled} />
                  </TouchableOpacity>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Numéro de téléphone</Text>
                  <View style={styles.inputWrapper}>
                    <Ionicons name="call-outline" size={18} color={COLORS.primary} />
                    <TextInput
                      style={styles.input}
                      placeholder="Ex: 699887766"
                      placeholderTextColor={COLORS.text.disabled}
                      keyboardType="phone-pad"
                      maxLength={9}
                      value={telephone}
                      onChangeText={setTelephone}
                      autoCorrect={false}
                    />
                  </View>
                </View>
              </View>
            )}

            {/* STEP 3 */}
            {etape === 2 && (
              <View>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Mot de passe</Text>
                  <View style={styles.inputWrapper}>
                    <Ionicons name="lock-closed-outline" size={18} color={COLORS.primary} />
                    <TextInput
                      style={styles.inputFlex}
                      placeholder="Min. 6 caractères"
                      placeholderTextColor={COLORS.text.disabled}
                      secureTextEntry={!showPass}
                      value={password}
                      onChangeText={setPassword}
                      autoCorrect={false}
                    />
                    <TouchableOpacity onPress={() => setShowPass(!showPass)} style={styles.eyeBtn}>
                      <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={18} color={COLORS.text.disabled} />
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Confirmer le mot de passe</Text>
                  <View style={styles.inputWrapper}>
                    <Ionicons name="shield-checkmark-outline" size={18} color={COLORS.primary} />
                    <TextInput
                      style={styles.inputFlex}
                      placeholder="Répétez le mot de passe"
                      placeholderTextColor={COLORS.text.disabled}
                      secureTextEntry={!showCoPass}
                      value={copassword}
                      onChangeText={setCopassword}
                      autoCorrect={false}
                    />
                    <TouchableOpacity onPress={() => setShowCoPass(!showCoPass)} style={styles.eyeBtn}>
                      <Ionicons name={showCoPass ? 'eye-off-outline' : 'eye-outline'} size={18} color={COLORS.text.disabled} />
                    </TouchableOpacity>
                  </View>
                </View>

                {/* ── CHECKBOX POLITIQUE ── */}
                <Animated.View style={[
                  styles.checkboxContainer,
                  !acceptePolitique && styles.checkboxContainerError,
                  { transform: [{ translateX: shakeAnim }] }
                ]}>
                  <TouchableOpacity
                    style={styles.checkboxRow}
                    onPress={() => setAcceptePolitique(!acceptePolitique)}
                    activeOpacity={0.7}
                  >
                    <View style={[styles.checkbox, acceptePolitique && styles.checkboxChecked]}>
                      {acceptePolitique && (
                        <Ionicons name="checkmark" size={13} color="#fff" />
                      )}
                    </View>
                    <View style={styles.checkboxTextWrap}>
                      <Text style={styles.checkboxText}>
                        J'ai lu et j'accepte la{' '}
                        <Text
                          style={styles.checkboxLink}
                          onPress={ouvrirPolitique}
                        >
                          politique de confidentialité
                        </Text>
                        {' '}de LaTchop.
                      </Text>
                    </View>
                  </TouchableOpacity>
                </Animated.View>
              </View>
            )}

            {/* Navigation */}
            <View style={styles.navRow}>
              {etape > 0 && (
                <TouchableOpacity style={styles.btnRetour} onPress={retour}>
                  <Ionicons name="arrow-back" size={18} color={COLORS.primary} />
                  <Text style={styles.btnRetourText}>Retour</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity
                style={[
                  styles.btnSuivant,
                  etape === 0 && { flex: 1 },
                  etape === 2 && !acceptePolitique && styles.btnSuivantDisabled,
                ]}
                onPress={etape < 2 ? validerEtape : handleInscription}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color="#fff" />
                  : <>
                      <Text style={styles.btnSuivantText}>
                        {etape < 2 ? 'Continuer' : 'Créer mon compte'}
                      </Text>
                      {etape < 2 && <Ionicons name="arrow-forward" size={18} color="#fff" />}
                    </>
                }
              </TouchableOpacity>
            </View>

            <View style={styles.linkRow}>
              <Text style={styles.linkText}>Déjà un compte ? </Text>
              <Link href="/auth/login" asChild>
                <TouchableOpacity>
                  <Text style={styles.link}>Se connecter</Text>
                </TouchableOpacity>
              </Link>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.primary },
  content: { flex: 1 },
  bgCircle: {
    position: 'absolute',
    width: width,
    height: width,
    borderRadius: width / 2,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    top: -width / 2,
    left: -width / 2,
  },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: SPACING.lg, paddingVertical: 40 },
  header: { alignItems: 'center', marginBottom: SPACING.xl },
  logoContainer: { width: 80, height: 80, borderRadius: RADIUS.xl, backgroundColor: '#fff', overflow: 'hidden', marginBottom: 10, alignItems: 'center', justifyContent: 'center', ...SHADOWS.medium },
  logoImg: { width: 55, height: 55, resizeMode: 'contain' },
  brandName: { fontSize: 30, fontWeight: '900', color: '#fff' },
  
  progressContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.xl },
  progressStep: { flexDirection: 'row', alignItems: 'center' },
  progressDot: {
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.3)',
    alignItems: 'center', justifyContent: 'center',
  },
  progressDotActive: { backgroundColor: '#fff' },
  progressDotDone: { backgroundColor: '#fff' },
  progressNum: { fontSize: 12, fontWeight: '700', color: COLORS.primary },
  progressNumActive: { color: '#fff' },
  progressLine: { width: 30, height: 2, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 4 },
  progressLineDone: { backgroundColor: '#fff' },

  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.xl,
    padding: SPACING.xl,
    ...SHADOWS.heavy,
  },
  etapeHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: SPACING.lg, paddingBottom: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  etapeIconWrap: { width: 40, height: 40, borderRadius: 10, backgroundColor: COLORS.primary + '15', alignItems: 'center', justifyContent: 'center' },
  etapeSous: { fontSize: 10, color: COLORS.primary, fontWeight: '700', textTransform: 'uppercase' },
  etapeTitre: { fontSize: 16, fontWeight: '800', color: COLORS.text.primary },

  inputGroup: { marginBottom: SPACING.md },
  label: { fontSize: 14, fontWeight: '700', color: COLORS.text.primary, marginBottom: 6 },
  inputWrapper: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1, borderColor: COLORS.border,
    borderRadius: RADIUS.md, paddingHorizontal: SPACING.md, height: 52,
  },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 16, color: COLORS.text.primary },
  eyeBtn: { padding: 8 },
  selectText: { flex: 1, fontSize: 16, color: COLORS.text.primary },

  checkboxContainer: {
    borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.md,
    padding: 12, backgroundColor: COLORS.background, marginBottom: SPACING.md,
  },
  checkboxContainerError: { borderColor: COLORS.error + '40', backgroundColor: COLORS.error + '08' },
  checkboxRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  checkbox: {
    width: 20, height: 20, borderRadius: 4,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: 'center', justifyContent: 'center', marginTop: 2,
  },
  checkboxChecked: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  checkboxTextWrap: { flex: 1 },
  checkboxText: { fontSize: 13, color: COLORS.text.secondary, lineHeight: 18 },
  checkboxLink: { color: COLORS.primary, fontWeight: '700' },

  navRow: { flexDirection: 'row', gap: 10, marginTop: SPACING.lg },
  btnRetour: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    borderWidth: 1.5, borderColor: COLORS.primary, borderRadius: RADIUS.md,
    height: 52, paddingHorizontal: 16,
  },
  btnRetourText: { color: COLORS.primary, fontSize: 15, fontWeight: '700' },
  btnSuivant: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: COLORS.primary, borderRadius: RADIUS.md, height: 52,
    ...SHADOWS.medium,
  },
  btnSuivantDisabled: { backgroundColor: COLORS.text.disabled, shadowOpacity: 0, elevation: 0 },
  btnSuivantText: { color: '#fff', fontSize: 16, fontWeight: '700' },

  linkRow: { flexDirection: 'row', justifyContent: 'center', marginTop: SPACING.lg },
  linkText: { fontSize: 14, color: COLORS.text.secondary },
  link: { fontSize: 14, color: COLORS.primary, fontWeight: '700' },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContainer: { backgroundColor: '#fff', borderTopLeftRadius: RADIUS.xl, borderTopRightRadius: RADIUS.xl, maxHeight: '85%', paddingBottom: 30 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  modalTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text.primary },
  searchWrapper: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.md, paddingHorizontal: 12, margin: 16, backgroundColor: COLORS.background, height: 44 },
  searchInput: { flex: 1, fontSize: 16, color: COLORS.text.primary, marginLeft: 8 },
  arrLabel: { fontSize: 12, fontWeight: '800', color: COLORS.primary, textTransform: 'uppercase', paddingHorizontal: 20, paddingVertical: 10, backgroundColor: COLORS.primary + '10' },
  quartierItem: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  quartierItemSelected: { backgroundColor: COLORS.primary + '10' },
  quartierText: { fontSize: 15, color: COLORS.text.secondary, flex: 1 },
  quartierTextSelected: { color: COLORS.primary, fontWeight: '700' },
});
