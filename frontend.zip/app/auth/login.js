// app/auth/login.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  ScrollView, ActivityIndicator,
  Image,
  StatusBar, Dimensions,
} from 'react-native';
import { useRouter, Link } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useAlert } from '../../context/AlertContext';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, RADIUS, TYPOGRAPHY, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');

export default function LoginScreen() {
  const router = useRouter();
  const { connexion } = useAuth();
  const { showAlert } = useAlert();
  const [telephone, setTelephone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleConnexion = async () => {
    if (!telephone || !password) {
      showAlert({
        title: 'Champs manquants',
        message: 'Veuillez remplir tous les champs.',
        type: 'warning',
      });
      return;
    }
    if (telephone.length !== 9) {
      showAlert({
        title: 'Téléphone invalide',
        message: 'Le numéro doit contenir 9 chiffres.',
        type: 'error',
      });
      return;
    }
    setLoading(true);
    try {
      const data = await connexion(telephone, password);
      if (data.status === 'success') {
        router.replace('/(tabs)');
      } else {
        showAlert({
          title: 'Erreur',
          message: data.message,
          type: 'error',
        });
      }
    } catch (e) {
      showAlert({
        title: 'Problème de connexion',
        message: 'Le serveur est inaccessible. Vérifiez votre internet et le serveur backend.',
        type: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Background Decoration */}
      <View style={styles.bgCircle} />
      <View style={[styles.bgCircle, { top: -100, right: -100, width: 300, height: 300, opacity: 0.3 }]} />

      <KeyboardAvoidingView
        style={styles.content}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header Area */}
          <View style={styles.header}>
            <View style={styles.logoContainer}>
              <Image source={require('../../assets/logo.png')} style={styles.logoImg} resizeMode="contain" />
            </View>
            <Text style={styles.brandName}>LaTchop</Text>
            <Text style={styles.tagline}>Local • Rapide • Délicieux</Text>
          </View>

          {/* Login Card */}
          <View style={styles.card}>
            <Text style={styles.title}>Bienvenue !</Text>
            <Text style={styles.subtitle}>Connectez-vous pour continuer</Text>

            {/* Téléphone */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Numéro de téléphone</Text>
              <View style={styles.inputWrapper}>
                <Ionicons name="call-outline" size={20} color={COLORS.primary} />
                <TextInput
                  style={styles.input}
                  placeholder="Ex: 699887766"
                  placeholderTextColor={COLORS.text.disabled}
                  keyboardType="phone-pad"
                  maxLength={9}
                  value={telephone}
                  onChangeText={setTelephone}
                  autoCorrect={false}
                />
              </View>
            </View>

            {/* Mot de passe */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Mot de passe</Text>
              <View style={styles.inputWrapper}>
                <Ionicons name="lock-closed-outline" size={20} color={COLORS.primary} />
                <TextInput
                  style={styles.input}
                  placeholder="Votre mot de passe"
                  placeholderTextColor={COLORS.text.disabled}
                  secureTextEntry={!showPassword}
                  value={password}
                  onChangeText={setPassword}
                  autoCorrect={false}
                />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
                  <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={20} color={COLORS.text.disabled} />
                </TouchableOpacity>
              </View>
            </View>

            {/* Bouton connexion */}
            <TouchableOpacity 
              style={[styles.btnPrimary, loading && { opacity: 0.7 }]} 
              onPress={handleConnexion} 
              disabled={loading}
            >
              {loading
                ? <ActivityIndicator color="#fff" />
                : <Text style={styles.btnPrimaryText}>Se connecter</Text>
              }
            </TouchableOpacity>

            {/* Lien inscription */}
            <View style={styles.footerLink}>
              <Text style={styles.footerText}>Pas encore de compte ? </Text>
              <Link href="/auth/signup" asChild>
                <TouchableOpacity>
                  <Text style={styles.link}>S'inscrire</Text>
                </TouchableOpacity>
              </Link>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.primary },
  content: { flex: 1 },
  bgCircle: {
    position: 'absolute',
    width: width * 0.8,
    height: width * 0.8,
    borderRadius: (width * 0.8) / 2,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    top: -50,
    left: -50,
  },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: SPACING.lg },
  header: { alignItems: 'center', marginBottom: SPACING.xl },
  logoContainer: {
    width: 100,
    height: 100,
    borderRadius: RADIUS.xl,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.md,
    ...SHADOWS.medium,
    padding: 10,
  },
  logoImg: { width: '100%', height: '100%' },
  brandName: { fontSize: 36, fontWeight: '900', color: '#fff', letterSpacing: 1 },
  tagline: { fontSize: 16, color: 'rgba(255,255,255,0.8)', marginTop: 4, fontWeight: '500' },
  
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.xl,
    padding: SPACING.xl,
    ...SHADOWS.heavy,
  },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.text.primary, marginBottom: 4 },
  subtitle: { fontSize: 15, color: COLORS.text.secondary, marginBottom: SPACING.xl },
  
  inputGroup: { marginBottom: SPACING.md },
  label: { fontSize: 14, fontWeight: '700', color: COLORS.text.primary, marginBottom: 6 },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    paddingHorizontal: SPACING.md,
    height: 56,
  },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 16, color: COLORS.text.primary },
  eyeBtn: { padding: 8 },
  
  btnPrimary: {
    backgroundColor: COLORS.primary,
    borderRadius: RADIUS.md,
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: SPACING.sm,
    ...SHADOWS.medium,
  },
  btnPrimaryText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  
  footerLink: { flexDirection: 'row', justifyContent: 'center', marginTop: SPACING.xl },
  footerText: { fontSize: 15, color: COLORS.text.secondary },
  link: { fontSize: 15, color: COLORS.primary, fontWeight: '700' },
});
